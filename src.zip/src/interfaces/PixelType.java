package interfaces;

/**
 * Interface for the representations of the type of Pixel. Represents either the RGB Pixel
 * or the HSL Pixel.
 */
public interface PixelType {

}
